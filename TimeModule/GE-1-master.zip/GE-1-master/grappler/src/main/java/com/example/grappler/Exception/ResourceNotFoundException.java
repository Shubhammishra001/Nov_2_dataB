package com.example.grappler.Exception;

public class ResourceNotFoundException extends RuntimeException{
    public ResourceNotFoundException(String resourceNotFound) {
    }
}
