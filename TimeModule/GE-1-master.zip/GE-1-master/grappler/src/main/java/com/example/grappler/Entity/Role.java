package com.example.grappler.Entity;

public enum Role {

    USERS,ADMIN;
}

