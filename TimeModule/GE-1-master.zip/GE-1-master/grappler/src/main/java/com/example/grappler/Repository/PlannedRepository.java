package com.example.grappler.Repository;

import com.example.grappler.Entity.Planed;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PlannedRepository extends JpaRepository<Planed,Long> {
}
