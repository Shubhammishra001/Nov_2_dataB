package com.example.grappler.Repository;

import com.example.grappler.Entity.AssignmentHistory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AssignmentHistoryRepository extends JpaRepository<AssignmentHistory,Long> {
}
