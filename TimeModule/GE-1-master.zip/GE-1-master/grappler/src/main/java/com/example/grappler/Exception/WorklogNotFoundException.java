package com.example.grappler.Exception;

public class WorklogNotFoundException extends RuntimeException {
    public WorklogNotFoundException(String message) {
        super(message);
    }
    }

