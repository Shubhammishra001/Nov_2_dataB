package com.example.grappler.Repository;

import com.example.grappler.Entity.Ticket_assign;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Ticket_assignRepository extends JpaRepository<Ticket_assign,Long> {
}
