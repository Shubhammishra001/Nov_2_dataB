package com.example.grappler;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GrapplerApplicationTests {

	@Test
	void contextLoads() {
	}

}
