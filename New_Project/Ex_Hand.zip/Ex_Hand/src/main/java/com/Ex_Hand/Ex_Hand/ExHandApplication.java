package com.Ex_Hand.Ex_Hand;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExHandApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExHandApplication.class, args);
	}

}
