package com.Ex_Hand.Ex_Hand;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExHandApplicationTests {

	@Test
	void contextLoads() {
	}

}
