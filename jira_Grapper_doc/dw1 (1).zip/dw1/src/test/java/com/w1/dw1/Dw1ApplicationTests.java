package com.w1.dw1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Dw1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
