package com.w1.dw1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Dw1Application {

	public static void main(String[] args) {
		SpringApplication.run(Dw1Application.class, args);
	}

}
